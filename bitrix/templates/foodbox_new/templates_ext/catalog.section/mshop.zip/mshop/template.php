<?php

if (!empty($arParams["TEMPLATE_AJAX_ID"])) {
    echo '<div id="' . $arParams['TEMPLATE_AJAX_ID'] . '">';
}

if ($arResult['TEMPLATE_DEFAULT']['TEMPLATE'] == 'showcase') {
    include($_SERVER['DOCUMENT_ROOT'] . SITE_TEMPLATE_PATH .
            '/templates_ext/catalog.section/mshop/showcase.php');
} elseif ($arResult['TEMPLATE_DEFAULT']['TEMPLATE'] == 'list') {
    include($_SERVER['DOCUMENT_ROOT'] . SITE_TEMPLATE_PATH .
            '/templates_ext/catalog.section/mshop/list.php');
} elseif ($arResult['TEMPLATE_DEFAULT']['TEMPLATE'] == 'showcase_little') {
    include($_SERVER['DOCUMENT_ROOT'] . SITE_TEMPLATE_PATH .
            '/templates_ext/catalog.section/mshop/showcase_little.php');
}

if (!empty($arParams["TEMPLATE_AJAX_ID"])) {
    echo '</div>';
}