<?php
$MESS['RS.MONOPOLY.BTN_MORE'] = 'Подробнее';
$MESS['RS.MONOPOLY.BTN_BUY'] = 'Купить';
$MESS['RS.MONOPOLY.BTN_GO2BASKET'] = 'В корзине';
$MESS['RS.MONOPOLY.ARTICLE'] = 'ID';
$MESS['RS.MONOPOLY.COMPARE'] = 'Сравнить';
$MESS['RS.MONOPOLY.QUANTITY'] = 'Наличие';
	$MESS['RS.MONOPOLY.QUANTITY_EMPTY'] = 'нет';
	$MESS['RS.MONOPOLY.QUANTITY_ISSET'] = 'есть';

$MESS['RS.MONOPOLY.NO_PRODUCTS'] = 'В данной категории товаров нет';

// QB and DA2
$MESS['QB_ICON_TITLE'] = 'Успей купить';
$MESS['DA2_ICON_TITLE'] = 'Товар дня';
$MESS['QB_AND_DA2_TITLE'] = 'До конца распродажи осталось';
$MESS['QB_AND_DA2_DAY'] = 'дн.';
$MESS['QB_AND_DA2_HOUR'] = 'час.';
$MESS['QB_AND_DA2_MIN'] = 'мин.';
$MESS['QB_AND_DA2_SEC'] = 'сек.';
$MESS['QB_AND_DA2_QUANTITY'] = 'осталось';
$MESS['QB_AND_DA2_PRODANO'] = 'продано';
$MESS['QB_AND_DA2_PERSENT'] = '%';
$MESS['QB_AND_DA2_SHT'] = 'шт.';