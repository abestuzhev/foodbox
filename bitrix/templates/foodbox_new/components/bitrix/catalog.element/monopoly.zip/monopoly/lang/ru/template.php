<?
$MESS['RS.MONOPOLY.ARTICLE'] = 'Код товара';
$MESS['RS.MONOPOLY.PRICE'] = 'Цена';
$MESS['RS.MONOPOLY.DISCOUNT'] = 'Ваша выгода';
$MESS['RS.MONOPOLY.QUANTITY'] = 'Наличие';
	$MESS['RS.MONOPOLY.QUANTITY_EMPTY'] = 'нет';
	$MESS['RS.MONOPOLY.QUANTITY_ISSET'] = 'есть';
$MESS['RS.MONOPOLY.MORE'] = 'Подробнее';
$MESS['RS.MONOPOLY.COMPARE'] = 'Сравнить';
$MESS['RS.MONOPOLY.MORE_PROPS'] = 'Все характеристики';
$MESS['RS.MONOPOLY.BTN_BUY'] = 'Купить';
$MESS['RS.MONOPOLY.BTN_GO2BASKET'] = 'В корзине';
$MESS['RS.MONOPOLY.BUY_BTN_TITLE'] = 'Покупка товара';
$MESS['RS.MONOPOLY.ASK_US'] = 'Задать вопрос';
$MESS['RS.MONOPOLY.ASK_US_TITLE'] = 'Задайте свой вопрос';
$MESS['RS.MONOPOLY.BUY_1_CLICK'] = 'Купить в 1 клик';
$MESS['RS.MONOPOLY.BUY_1_CLICK_TITLE'] = 'Купить в 1 клик';
$MESS['RS.MONOPOLY.CREDIT_BTN'] = 'Купить в кредит';
$MESS['RS.MONOPOLY.YASHARE'] = 'Рассказать друзьям';
$MESS['RS.MONOPOLY.PRODUCT_COLLECTION'] = 'Коллекции ';

$MESS['RS.MONOPOLY.DESCRIPTION'] = 'Описание';
$MESS['RS.MONOPOLY.PROPERTIES'] = 'Характеристики';

$MESS['RS.MONOPOLY.IN_FAVORITE'] = 'Добавить в избранное';

// QB and DA2
$MESS['QB_ICON_TITLE'] = 'Успей<br />купить';
$MESS['DA2_ICON_TITLE'] = 'Товар<br />дня';
$MESS['QB_AND_DA2_TITLE'] = 'До конца распродажи осталось';
$MESS['QB_AND_DA2_DAY'] = 'дн.';
$MESS['QB_AND_DA2_HOUR'] = 'час.';
$MESS['QB_AND_DA2_MIN'] = 'мин.';
$MESS['QB_AND_DA2_SEC'] = 'сек.';
$MESS['QB_AND_DA2_QUANTITY'] = 'осталось';
$MESS['QB_AND_DA2_PRODANO'] = 'продано';
$MESS['QB_AND_DA2_PERSENT'] = '%';
$MESS['QB_AND_DA2_SHT'] = 'шт.';

$MESS['RSMONOPOLY_DS_DL'] = 'Скачать';