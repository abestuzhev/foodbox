<?
$MESS["SALE_ORDER"] = "Оформить заказ";
$MESS["SALE_OR"] = "или";
$MESS["SALE_NAME"] = "Товар";
$MESS["SALE_PROPS"] = "Свойства";
$MESS["SALE_PRICE"] = "Цена";
$MESS["SALE_TYPE"] = "Тип цены";
$MESS["SALE_QUANTITY"] = "Количество";
$MESS["SALE_SUM"] = "Сумма";
$MESS["SALE_DELETE"] = "Удалить";
$MESS["SALE_DELAY"] = "Отложить";
$MESS["SALE_ADD_TO_BASKET"] = "Добавить к заказу";
$MESS["SALE_WEIGHT"] = "Вес";
$MESS["SALE_TOTAL_WEIGHT"] = "Общий вес:";
$MESS["SALE_WEIGHT_G"] = "г";
$MESS["SALE_DELAYED_TITLE"] = "Отложено";
$MESS["SALE_UNAVAIL_TITLE"] = "Отсутствуют";
$MESS["STB_ORDER_PROMT"] = "Для того чтобы начать оформление заказа, нажмите кнопку \"Оформить заказ\".";
$MESS["STB_COUPON_PROMT"] = "Промокод";
$MESS["SALE_VAT"] = "НДС:";
$MESS["SALE_VAT_EXCLUDED"] = "Товаров на:";
$MESS["SALE_VAT_INCLUDED"] = "В том числе НДС:";
$MESS["SALE_TOTAL"] = "Сумма заказа:";
$MESS["SALE_CONTENT_DISCOUNT"] = "Скидка";
$MESS["SALE_DISCOUNT"] = "Скидка";
$MESS["SALE_NOTIFY_TITLE"] = "Ожидаемые товары";
$MESS["SALE_REFRESH_NOTIFY_DESCR"] = "Нажмите эту кнопку, чтобы удалить товары.";
$MESS["SALE_ITEMS"] = "Товары в корзине:";
$MESS["SALE_BASKET_ITEMS"] = "Готовые к заказу";
$MESS["SALE_BASKET_ITEMS_DELAYED"] = "Отложенные";
$MESS["SALE_BASKET_ITEMS_SUBSCRIBED"] = "Ожидаемые";
$MESS["SALE_BASKET_ITEMS_NOT_AVAILABLE"] = "Отсутствуют";
$MESS["SALE_NO_ITEMS"] = "В вашей корзине ещё нет товаров.";
$MESS["SALE_REFRESH"] = "Пересчитать";
$MESS["SALE_COUNT_ITEMS"] = "Товаров: ";
$MESS["CHECK_COUPON"] = "Проверить";
$MESS["CLEAR_BASKET"] = "Очистить корзину";
$MESS["BUY1CLICK"] = "Купить в 1 клик";
$MESS["ITEM_CODE"] = "Код товара: ";


$MESS["COUPON"] = "Купон";
$MESS["SALE_BACK_TO_CATALOG"] = "Вернуться к покупкам";
?>