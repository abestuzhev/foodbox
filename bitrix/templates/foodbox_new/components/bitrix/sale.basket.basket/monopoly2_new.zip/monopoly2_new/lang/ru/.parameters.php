<?
$MESS["SALE_PROPERTIES_RECALCULATE_BASKET"] = "Свойства, влияющие на пересчет корзины";
$MESS["CP_SBB_TPL_THEME_SITE"] = "Брать тему из настроек сайта (для решения bitrix.eshop)";
$MESS["CP_SBB_TPL_THEME_BLUE"] = "синяя (тема по умолчанию)";
$MESS["CP_SBB_TPL_THEME_GREEN"] = "зеленая";
$MESS["CP_SBB_TPL_THEME_RED"] = "красная";
$MESS["CP_SBB_TPL_THEME_WOOD"] = "дерево";
$MESS["CP_SBB_TPL_THEME_YELLOW"] = "желтая";
$MESS["CP_SBB_TPL_THEME_BLACK"] = "темная";
$MESS["CP_SBB_TPL_TEMPLATE_THEME"] = "Цветовая тема";
?>