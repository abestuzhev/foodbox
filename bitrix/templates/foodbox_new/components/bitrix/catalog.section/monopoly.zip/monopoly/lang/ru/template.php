<?php
include($_SERVER['DOCUMENT_ROOT'].SITE_TEMPLATE_PATH.
        '/templates_ext/catalog.section/mshop/lang/ru/template.php');