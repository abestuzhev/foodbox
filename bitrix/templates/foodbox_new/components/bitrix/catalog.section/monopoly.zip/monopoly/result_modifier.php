<?php

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}


include($_SERVER['DOCUMENT_ROOT'] . SITE_TEMPLATE_PATH .
        '/templates_ext/catalog.section/mshop/result_modifier.php');
