<?
$MESS['RS.MONOPOLY.SMALLBASKET_TITLE'] = 'Корзина';
$MESS['RS.MONOPOLY.SMALLBASKET_TOVAR'] = 'товар';
$MESS['RS.MONOPOLY.SMALLBASKET_NA'] = 'на';
$MESS['RS.MONOPOLY.SMALLBASKET_PUSTO'] = 'Корзина пуста';
$MESS['RS.MONOPOLY.GOTO_BASKET'] = 'Перейти в корзину';
$MESS["SALE_NO_ITEMS"] = "В вашей корзине ещё нет товаров.";